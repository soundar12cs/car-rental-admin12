package com.carrental.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.carrental.entity.Booking;
import com.carrental.service.BookingService;

@RestController
@RequestMapping("/admin")
@CrossOrigin
public class AdminController {

    @Autowired
    private BookingService bookingService;

    // Admin Dashboard - View All Bookings
    @GetMapping("/dashboard")
    public List<Booking> getAllBookings() {
        return bookingService.getAllBookings();
    }

}




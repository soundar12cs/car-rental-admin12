package com.carrental.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.carrental.entity.Booking;
import com.carrental.service.BookingService;

@RestController
@RequestMapping("/bookings")
@CrossOrigin
public class BookingController {

@Autowired
BookingService service;


// CREATE BOOKING
@PostMapping
public Booking bookCar(@RequestBody Booking booking){
    return service.bookCar(booking);
}


// ADMIN VIEW BOOKINGS
@GetMapping("/admin")
public List<Booking> getAllBookings(){
    return service.getAllBookings();
}

}
package com.carrental.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dashboard")
@CrossOrigin
public class DashboardController {

@GetMapping
public String dashboard(){

return "Welcome to Car Rental System API";

}

@GetMapping("/status")
public String status(){

return "System Running Successfully";

}

}


package com.carrental.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.carrental.entity.Car;
import com.carrental.service.CarService;

@RestController
@RequestMapping("/cars")
@CrossOrigin
public class CarController {

@Autowired
CarService service;

@GetMapping
public List<Car> getCars(){
    return service.getAllCars();
}

@PostMapping
public Car addCar(@RequestBody Car car){
    return service.addCar(car);
}

@PutMapping("/{id}")
public Car updateCar(@PathVariable Long id,@RequestBody Car car){
    return service.updateCar(id,car);
}

@DeleteMapping("/{id}")
public void deleteCar(@PathVariable Long id){
    service.deleteCar(id);
}

}
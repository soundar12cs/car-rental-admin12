package com.carrental.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.carrental.entity.User;
import com.carrental.service.UserService;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UserController {

@Autowired
UserService service;

@GetMapping
public List<User> getUsers(){
return service.getAllUsers();
}

@GetMapping("/{id}")
public User getUser(@PathVariable Long id){
return service.getUserById(id);
}

@DeleteMapping("/{id}")
public void deleteUser(@PathVariable Long id){
service.deleteUser(id);
}

}


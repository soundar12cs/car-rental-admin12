package com.carrental.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.carrental.dto.LoginRequest;
import com.carrental.dto.LoginResponse;
import com.carrental.entity.User;
import com.carrental.repository.UserRepository;
import com.carrental.security.JwtUtil;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private JwtUtil jwt;

    // Register API
    @PostMapping("/register")
    public User register(@RequestBody User user) {

        user.setPassword(encoder.encode(user.getPassword()));

        return repo.save(user);
    }

    // Login API
    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest request) {

        User user = repo.findByUsername(request.getUsername());

        if (user != null && encoder.matches(request.getPassword(), user.getPassword())) {

            String token = jwt.generateToken(user.getUsername());

            return new LoginResponse(token);
        }

        throw new RuntimeException("Invalid login");
    }

}
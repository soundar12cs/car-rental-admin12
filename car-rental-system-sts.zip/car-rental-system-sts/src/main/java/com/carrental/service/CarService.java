package com.carrental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrental.entity.Car;
import com.carrental.repository.CarRepository;

@Service
public class CarService {

@Autowired
CarRepository repo;

public List<Car> getAllCars(){
    return repo.findAll();
}

public Car addCar(Car car){
    return repo.save(car);
}

public Car updateCar(Long id, Car car){

    Car existing = repo.findById(id).orElseThrow();

    existing.setBrand(car.getBrand());
    existing.setModel(car.getModel());
    existing.setPricePerDay(car.getPricePerDay());
    existing.setImageUrl(car.getImageUrl());
    existing.setAvailable(car.isAvailable());

    return repo.save(existing);
}

public void deleteCar(Long id){
    repo.deleteById(id);
}

}
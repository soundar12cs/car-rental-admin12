package com.carrental.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carrental.entity.Booking;
import com.carrental.repository.BookingRepository;

@Service
public class BookingService {

@Autowired
BookingRepository repo;

public Booking bookCar(Booking booking){
    return repo.save(booking);
}

public List<Booking> getAllBookings(){
    return repo.findAll();
}

}


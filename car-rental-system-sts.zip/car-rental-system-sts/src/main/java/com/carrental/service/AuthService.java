package com.carrental.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.carrental.entity.User;
import com.carrental.repository.UserRepository;

@Service
public class AuthService {

    @Autowired
    private UserRepository repo;

    @Autowired
    private PasswordEncoder encoder;

    public User register(User user) {

        user.setPassword(encoder.encode(user.getPassword()));

        return repo.save(user);
    }

    public User login(String username, String password) {

        User user = repo.findByUsername(username);

        if (user != null && encoder.matches(password, user.getPassword())) {
            return user;
        }

        throw new RuntimeException("Invalid username or password");
    }

}

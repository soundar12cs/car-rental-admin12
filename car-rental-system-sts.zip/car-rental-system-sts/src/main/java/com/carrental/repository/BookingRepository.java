package com.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.carrental.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking,Long>{

}

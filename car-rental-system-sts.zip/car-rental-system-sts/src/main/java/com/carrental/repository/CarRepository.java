package com.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.carrental.entity.Car;

public interface CarRepository extends JpaRepository<Car, Long>{

}